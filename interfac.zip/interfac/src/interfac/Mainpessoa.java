package interfac;

public class Mainpessoa {

}
