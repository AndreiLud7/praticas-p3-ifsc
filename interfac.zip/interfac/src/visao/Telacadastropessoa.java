package visao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.pessoa;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Telacadastropessoa extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtprimeironome;
	private JTextField txtsegundo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Telacadastropessoa frame = new Telacadastropessoa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Telacadastropessoa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 486, 267);
		contentPane = new JPanel();
		contentPane.setForeground(new Color(55, 47, 208));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel Primeironome = new JLabel("Primeiro nome");
		Primeironome.setBounds(54, 13, 67, 13);
		Primeironome.setFont(new Font("Arial", Font.PLAIN, 11));
		contentPane.add(Primeironome);
		
		txtprimeironome = new JTextField();
		txtprimeironome.setBounds(131, 9, 86, 20);
		contentPane.add(txtprimeironome);
		txtprimeironome.setColumns(10);
		
		JLabel segundonome = new JLabel("segundo nome");
		segundonome.setBounds(54, 44, 71, 13);
		segundonome.setFont(new Font("Arial", Font.PLAIN, 11));
		contentPane.add(segundonome);
		
		txtsegundo = new JTextField();
		txtsegundo.setBounds(131, 40, 86, 20);
		contentPane.add(txtsegundo);
		txtsegundo.setColumns(10);
		
		JButton cadastro = new JButton("cadastrar");
		cadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nome = txtprimeironome.getText();
				String sobrenome = txtsegundo.getText();
				
				if (nome.isEmpty() || sobrenome.isEmpty()) {
					JOptionPane.showMessageDialog(null, "Preencha o campo");
				}
				else {
					pessoa p = new pessoa();
					p.setPrimeironome(nome);
					p.setSobrenome(sobrenome);
					
					String msg = "Cadastrado\n " + "voce cadastrou: " + p.getPrimeironome() + " " + p.getSobrenome();
					JOptionPane.showMessageDialog(null, msg);
				}
			}
		});
		cadastro.setBounds(49, 112, 168, 23);
		contentPane.add(cadastro);
		
		JButton btnlimpa = new JButton("limpa");
		btnlimpa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {  
				txtsegundo.setText("");
				txtprimeironome.setText("");
			}
		});
		btnlimpa.setBounds(49, 78, 168, 23);
		contentPane.add(btnlimpa);

	}
}
