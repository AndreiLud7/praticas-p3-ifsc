package modelo;

public class cliente {

}
