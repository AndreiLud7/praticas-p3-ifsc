package modelo;

public class pessoa {

private String primeironome;
private String sobrenome;
public String getPrimeironome() {
	return primeironome;
}
public void setPrimeironome(String primeironome) {
	this.primeironome = primeironome;
}
public String getSobrenome() {
	return sobrenome;
}
public void setSobrenome(String sobrenome) {
	this.sobrenome = sobrenome;
}

	
}
	

